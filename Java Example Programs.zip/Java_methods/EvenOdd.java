class EvenOdd 
{
	public static void main(String[] args) 
	{
		int num=5;
		check(num);
	}
	public static void check(int num) 
	{
		if(num%2==0)
		{
			System.out.println(num+" is even number");
		}
		else
		{
			System.out.println(num+" is odd number");
		}
	}
}
