class VowelConst 
{
	public static void main(String[] args) 
	{
		char c='B';
		check(c);
		
	}
	public static void check(char c) 
	{
		if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U'||c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
		{
			System.out.println(c+ " is vowel");
		}
		else
		{
			System.out.println(c+ " is consonant");
		}
	}
}
