class MethodExample2 
{
	public static void main(String[] args) 
	{
		System.out.println("Main starts");
		m1();
		System.out.println("Main ends");
	}
	public static void m1() 
	{
		System.out.println("M1 starts");
		m2();
		System.out.println("M1 ends");
	}
	public static void m2() 
	{
		System.out.println("M2 starts");
		m3();
		System.out.println("M2 ends");
	}
	public static void m3() 
	{
		System.out.println("M3 starts");
		System.out.println("M3 ends");
	}
}
