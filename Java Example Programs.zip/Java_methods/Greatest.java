class Greatest 
{
	public static void main(String[] args) 
	{
		int a=4;
		int b=3;
		check(a,b);
		
	}
	public static void check(int x,int y) 
	{
		if(x>y)
		{
			System.out.println(x +" is greatest number");
		}
		else
		{
			System.out.println(y +" is greatest number");
		}
	}
}
