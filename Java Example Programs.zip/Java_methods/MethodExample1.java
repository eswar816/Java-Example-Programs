class MethodExample1 
{
	public static void main(String[] args) 
	{
		System.out.println("Main Starts");
		m1();
		m2();
		m3();
		m1();
		System.out.println("Main Ends");
	}
	public static void m1() 
	{
		System.out.println("M1 Starts");
		System.out.println("M1 Ends");
	}
	public static void m2() 
	{
		System.out.println("M2 Starts");
		System.out.println("M2 Ends");
	}
	public static void m3() 
	{
		System.out.println("M3 Starts");
		System.out.println("M3 Ends");
	}
}
