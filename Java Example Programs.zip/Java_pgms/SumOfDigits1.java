class SumOfDigits1 
{
	public static void main(String[] args) 
	{
		int num=12345,temp=num,sum=0,rem;
		while(num>0)
		{
			rem=num%10;
			sum=sum+rem;
			num=num/10;
		}
		System.out.println("Sum of digits of "+temp+" is = "+sum);
	}
}
