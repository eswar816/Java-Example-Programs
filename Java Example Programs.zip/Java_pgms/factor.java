class factor 
{
	public static void main(String[] args) 
	{
		int i,num=24;
		for(i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				System.out.println(i);
			}
		}
		
	}
}
