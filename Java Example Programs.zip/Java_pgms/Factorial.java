class Factorial 
{
	public static void main(String[] args) 
	{
		int num=5,temp=num,fact=1;
		while(num>0)
		{
			fact=fact*num;
			num--;
		}
		System.out.println("Factorial of "+temp+" is = "+fact);
	}
}
