class pgm5 
{
	public static void main(String[] args) 
	{
		int num=-3;
		if(num>=0)
		{
			if(num%2==0)
			{
				System.out.println("Zinga rocks");
			}
			else
			{
				System.out.println("Pinga rocks");
			}
		}
		else
		{
			System.out.println("Tinga rocks");
		}
		
	}
}
