class FactorCount 
{
	public static void main(String[] args) 
	{
		int i,num=6,count=0;
		for(i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				count++;
			}
		}
		System.out.println("The number of factors are " +count);
	}
}
