class Palindrome 
{
	public static void main(String[] args) 
	{
		int num=12321,temp=num,sum=0,rem,rev=0;
		while(num>0)
		{
			rem=num%10;
			num=num/10;
			rev=rev*10+rem;
		}
		if(rev==temp)
		{
			System.out.println("It is Palindrome");
		}
		else
		{
			System.out.println("It is not Palindrome");
		}
	}
}
