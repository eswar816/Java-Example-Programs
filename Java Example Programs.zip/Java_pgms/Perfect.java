class Perfect
{
	public static void main(String[] args) 
	{
		int i,num=14,sum=0;
		for(i=1;i<num;i++)
		{
			if(num%i==0)
			{
				sum=sum+i;
			}
		}
		if(sum==num)
		{
			System.out.println("It is perfect number");
		}
		else
		{
			System.out.println("It is not perfect number");
		}
	}
}
