class greatest 
{
	public static void main(String[] args) 
	{
		int num1=10;
		int num2=20;
		int num3=30;
		if(num1>num2 && num1>num3)
		{
			System.out.println("Num1 is greater");
		}
		else if(num2>num1 && num2>num3)
		{
			System.out.println("Num2 is greater");
		}
		else if(num3>num1 && num3>num1)
		{
			System.out.println("Num3 is greater");
		}
		else
		{
			System.out.println("All are equal");
		}
	}
}
