class RevStrArr 
{
	public static void main(String[] args) 
	{
		String[] s={"Sai","eswar","Hello"};
		revArr(s);
		//System.out.println("Hello World!");
	}
	public static void revArr(String[] s)
	{
		int len=s.length;
		for(int i=len-1;i>=0;i--)
		{
			System.out.println(s[i]);
		}
	}
}
