class FinDupStr 
{
	public static void main(String[] args) 
	{
		String[] s={"Sai","Sai","Eswar","guru","Eswar"};
		findDup(s);
	}
	public static void findDup(String[] a)
	{
		int len=a.length,k=0;
		String[] s1=new String[len];;
		for(int i=0;i<len;i++)
		{
			for(int j=i+1;j<len;j++)
			{
				if(!(a[j].equals(" ")))
				{
					if(a[i].equals(a[j]))
					{
						s1[k++]=a[i];
						a[j]=" ";
					}
				}
			}
		}
		for(int i=0;i<k;i++)
		{
			if(!(s1[i].equals(" ")))
			{
				System.out.println(s1[i]);
			}
		}
	}
}
