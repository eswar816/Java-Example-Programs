class FindFirSecLar 
{
	public static void main(String[] args) 
	{
		int[] a={17,8,12,9,18};
		firSecLar(a);
	}
	public static void firSecLar(int[] a)
	{
		int i,j,Flar=0,Slar=0;
		for(i=0;i<=a.length;i++)
		{
			for(j=i+1;j<=a.length;j++)
			{
				if(a[i]>Flar)
				{
					Slar=Flar;
					Flar=a[i];
				}
				else if(a[i]>Slar && a[i]!=Flar)
				{
					Slar=a[i];
				}
			}
		}
		System.out.println("First largest is "+Flar);
		System.out.println("Second largest is "+Slar);
	}
}
