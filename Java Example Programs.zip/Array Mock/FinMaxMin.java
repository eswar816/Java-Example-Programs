import java.util.*;
class FinMaxMin
{
	public static void main(String[] args) 
	{
		int[] a={2,3,4,6,9,10};
		finMisRep(a);
	}
	public static void finMisRep(int[] a)
	{
		int len=a.length,max=a[0],min=a[0],temp=0;
		Arrays.sort(a);
		for(int i=1;i<len;i++)
		{
			if(a[i]>max)
			{
				temp=a[i];
				a[i]=max;
				max=temp;
			}
		}
		for(int i=1;i<len;i++)
		{
			if(a[i]<min)
			{
				temp=a[i];
				a[i]=min;
				min=temp;
			}
		}
		System.out.println("Maximum number is "+max);
		System.out.println("Minimum number is "+min);
	}
}
