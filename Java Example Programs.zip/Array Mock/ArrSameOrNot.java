import java.util.*;
class ArrSameOrNot 
{
	public static void main(String[] args) 
	{
		int[] a={1,2,3,4,5};
		int[] b={2,1,3,5,4};
		
		if(arrSameOrNot(a,b))
		{
			System.out.println("Arrays are equal");
		}
		else
		{
			System.out.println("Arrays are not equal");
		}
	}
	public static boolean arrSameOrNot(int[] a,int[] b)
	{
		int l1=a.length;
		int l2=b.length;
		int count=0;
		if(l1!=l2)
		{
			System.out.println("Arrays are not equal");
		}
		Arrays.sort(a);
		Arrays.sort(b);
		for (int i = 0; i < l1; i++)
		{
			 if (a[i] != b[i])
			{
				return false;
			}
                
		}
        return true;
		
	}
}
