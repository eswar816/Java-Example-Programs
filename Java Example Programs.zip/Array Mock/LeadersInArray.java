class LeadersInArray
{
	 public static void main(String[] args)
    {
        LeadersInArray lead = new LeadersInArray();
        int[] a= {16, 17, 4, 3, 5, 2};
        int n = a.length;
        lead.printLeaders(a, n);
    }
    public static void printLeaders(int[] a, int size)
    {
		int count=0,j=0;
		int[] b=new int[50];
		int max=a[size-1];
		b[j]=max; j++;
        for(int i=size-1;i>=0;i--)
		{
			if(max<a[i])
			{
				max=a[i];
				b[j]=max;
				count++;
				j++;
			}
		}
		for(j=count;j>=0;j--)
		{
			System.out.print(b[j]+" ");
		}
    }  
}