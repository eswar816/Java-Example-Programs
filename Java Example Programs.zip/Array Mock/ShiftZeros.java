class ShiftZeros 
{
	public static void main(String[] args) 
	{
		int[] a={4,0,5,0,6,7,0,1};
		shiftZeros(a);
	}
	public static void shiftZeros(int[] a)
	{
		int len=a.length,count=0;
        for (int i = 0; i < len; i++)
		{
			 if (a[i] != 0)
			{
				a[count++] = a[i]; 
			}
		}
        while (count < len)
		{
			a[count++] = 0;
		}    
		for(int i=0;i<len;i++)
		{
			System.out.println(a[i]);
		}
	}
}
