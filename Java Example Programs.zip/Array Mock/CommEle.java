class CommEle 
{
	public static void main(String[] args) 
	{
		int[] a={2,3,4,5,1};
		int[] b={2,4,8,9};
		finCommEle(a,b);
	}
	public static void finCommEle(int[] a,int[] b)
	{
		int flag=0;
		int l1=a.length;
		int l2=b.length;
		for(int i=0;i<l1;i++)
		{
			for(int j=0;j<l2;j++)
			{
				if(b[j]!=0)
				{
					if(a[i]==b[j])
					{
						flag=1;
						b[j]=0;
						System.out.println(a[i]);
					}
				}
			}
		}
		if(flag==0)
		{
			System.out.println("No Common elements");
		}
	}
}
