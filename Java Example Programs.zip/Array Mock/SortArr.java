class SortArr 
{
	public static void main(String[] args) 
	{
		int[] a={6,3,7,8,2,4,7,3,1};
		sortArr(a);
	}
	public static void sortArr(int[] a)
	{
		int i,j,len=a.length,temp=0;
		for(i=0;i<len;i++)
		{
			for(j=i+1;j<len;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		for(i=0;i<len;i++)
		{
			System.out.println(a[i]);
		}
	}
}
