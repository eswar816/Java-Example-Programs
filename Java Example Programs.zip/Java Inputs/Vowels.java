class Vowels 
{
	public static void main(String[] args) 
	{
		String s="Hello";
		for(int i=s.length()-1;i>=0;i--)
		{
			 char ch=s.charAt(i);
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
			{
				System.out.println(ch);
			}
		}
	}
}
