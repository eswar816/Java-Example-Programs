import java.util.Scanner;
class Factorial 
{
	public static int fact(int len)
	{
		
		int res=1;
		if(len==0 || len==1)
		{
			return 1;
		}
		else
		{
			for(int i=2;i<=len;i++)
			{
				res=res*i;
			}
			return res;
		}
	}
	public static void main(String[] args) 
	{
		Scanner n=new Scanner(System.in);
		System.out.println("Enter the length");
		int len=n.nextInt();
		int factorial=fact(len);
		System.out.println("The factorial of" +len+ "is "+ factorial);
	}
}
