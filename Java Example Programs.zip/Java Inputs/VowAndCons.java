class VowAndCons
{
	public static void main(String[] args) 
	{
		String s="Hello";
		int c1=0,c2=0;
		char ch;
		for(int i=0;i<s.length();i++)
		{
			ch=s.charAt(i);
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
			{
				c1++;
			}
			else
			{
				c2++;
			}
		}
		System.out.println("Number of vowels:" + c1);
		System.out.println("NUmber of Consonants:" + c2);
	}
}
