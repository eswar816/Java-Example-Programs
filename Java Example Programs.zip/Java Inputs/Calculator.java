import java.util.Scanner;
class Calculator 
{
	public static void calc(int num1,int num2)
	{
		Scanner n1=new Scanner(System.in);
		System.out.println("Enter your choice");
		char choice=n1.next().charAt(0);
		switch(choice)
		{
			case'+':System.out.println("Addition of" + num1 + "and "+ num2 +" is "+ add(num1,num2));
				break;
			case'-':System.out.println("Subtraction of" + num1 + "and "+ num2 +" is "+ sub(num1,num2));
				break;
			case'*':System.out.println("Multiplication of" + num1 + "and "+ num2 +" is "+ mul(num1,num2));
				break;
			case'/':System.out.println("Division of" + num1 + "and "+ num2 +" is "+ div(num1,num2));
				break;
			default:System.out.println("Please select a valid option");
		}
	}
	public static int add(int num1,int num2)
	{
		
		return num1+num2;
	}
	public static int sub(int num1,int num2)
	{

		return num1-num2;
	}
	public static int mul(int num1,int num2)
	{
		
		return num1*num2;
	}
	public static int div(int num1,int num2)
	{
		
		return num1/num2;
	}
	public static void main(String[] args) 
	{
		Scanner n=new Scanner(System.in);
		int a,b,result;
		System.out.println("Enter the first value");
		a=n.nextInt();
		System.out.println("Enter the second value");
		b=n.nextInt();
		calc(a,b);
	}
}
