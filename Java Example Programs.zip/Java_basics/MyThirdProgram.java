class MyThirdProgram 
{
	public static void main(String[] args) 
	{
		System.out.print("Hello");
		System.out.print(" Welcome ");
		System.out.println(" to ");
		System.out.print("java ");
		System.out.println("Classes");
		System.out.print(" by ");
		System.out.print("Dinga  !!!");
	}
}
