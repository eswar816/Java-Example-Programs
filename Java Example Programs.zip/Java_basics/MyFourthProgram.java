class MyFourthProgram 
{
	public static void main(String[] args) 
	{
		int a=100;
		System.out.println("a");
		System.out.println(a);
		System.out.println(a * 10);
		System.out.println(a-'	');
		a=50;
		System.out.println(a);
		System.out.println(a+'a');
		System.out.println("a="+a);
	}
}