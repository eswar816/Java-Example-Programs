class MySecondProgram 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello" + 10);
		System.out.println("Hello" + 'A');
		System.out.println(10 + 'A');
		System.out.println("Hello" + 10 +20);
		System.out.println(10+20+"Hello");
		System.out.println('a' + 10);
		System.out.println(' ' + 10);
		System.out.println('$' + 10);
		System.out.println('	' + 1);
	}
}
