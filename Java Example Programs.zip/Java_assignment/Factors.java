class Factors
{
	public static void main(String[] args) 
	{
		int num=12;
		factors(num);
	}
	public static void factors(int num)
	{
		int count=0,i;
		for(i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				System.out.println(i);	
			}
		}
	}
}
