class GreatestThree 
{
	public static void main(String[] args) 
	{
		int num1=4,num2=5,num3=6;
		check(num1,num2,num3);

		
	}
	public static void check(int a,int b,int c)
	{
		if(a>b&&a>c)
		{
			System.out.println(a+" is greater");
		}
		else if(b>a&&b>c)
		{
			System.out.println(b+" is greater");
		}
		else if(c>a&&c>b)
		{
			System.out.println(c+" is greater");
		}
		else 
		{
			System.out.println("All are equal");
		}

	}
}
