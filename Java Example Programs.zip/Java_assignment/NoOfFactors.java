class NoOfFactors 
{
	public static void main(String[] args) 
	{
		int num=12;
		count(num);
	}
	public static void count(int a)
	{
		int count=0;
		for(int i=1;i<a;i++)
		{
			if(a%i==0)
			{
				count++;
			}
		}
		System.out.println("Sum of factors is "+count);
	}
}
