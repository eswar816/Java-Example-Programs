class SwapTwoNumbers2
{
	public static void main(String[] args) 
	{
		int num1=100,num2=200;
		System.out.println("Before Swaping");
		System.out.println(num1);
		System.out.println(num2);
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("After Swaping");
		System.out.println(num1);
		System.out.println(num2);
	}
}