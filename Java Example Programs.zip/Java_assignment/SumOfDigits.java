class SumOfDigits 
{
	public static void main(String[] args) 
	{
		int num=5;
		check(num);
		
	}
	public static void check(int a)
	{
		int sum=0;
		for(int i=1;i<=a;i++)
		{
			sum=sum+i;
		}
		System.out.println("Sum is "+sum);
	}
}
