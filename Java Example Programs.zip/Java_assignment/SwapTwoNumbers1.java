class SwapTwoNumbers1 
{
	public static void main(String[] args) 
	{
		int num1=100,num2=200;
		int temp;
		System.out.println("Before Swaping");
		System.out.println(num1);
		System.out.println(num2);
		temp=num1;
		num1=num2;
		num2=temp;
		System.out.println("After Swaping");
		System.out.println(num1);
		System.out.println(num2);
	}
}
