class XylemPhloem 
{
	public static void main(String[] args) 
	{
		int n=36328;
		if(isXylemPhloem(n))
		{
			System.out.println("It is a Xylem number");
		}
		else
		{
			System.out.println("It is a phloem number");
		}
	}
	public static boolean isXylemPhloem(int n)
	{
		int[] a=new int[count(n)];
		int temp=n,rem,sum2=0;
		while(temp!=0)
		{
			rem=temp%10;
			for(int i=0;i<a.length;i++)
			{
				a[i]=rem;
			}
			temp/=10;
		}
		int sum1=a[0]+a[a.length-1];
		for(int i=1;i<a.length-2;i++)
		{
			sum2+=a[i];
		}
		return sum1==sum2?true:false;
	}
	public static int count(int n)
	{
		int count=0;
		while(n!=0)
		{
			count++;
			n=n/10;
		}
		return count;
	}
}
