class AltPrime 
{
	public static void main(String[] args) 
	{
		int n=20;
		isPrime(n);
	}
	public static void isPrime(int n)
	{
		int[] a=new int[n];
		for(int i=2,j=0;i<=n;i++)
		{
			if(checkPrime(i))
			{
				a[j]=i;
				j++;
			}
			else{}
		}
		for(int i=0;i<=a.length-1;i+=2)
		{
			if(a[i]!=0)
			{
				System.out.println(a[i]);
			}
		}
	}
	public static boolean checkPrime(int n)
	{
		for(int i=2;i<n;i++)
		{
			if(n%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
