class Armstrong 
{
	public static void main(String[] args) 
	{
		int n=317;
		if(isArmstrong(n))
		{
			System.out.println(n+" is an amstrong number");
		}
		else
		{
			System.out.println(n+" is not an armstrong number");
		}
		
	}
	public static boolean isArmstrong(int n)
	{
		int temp=n,sum=0;
		int count=count(n);
		while(temp!=0)
		{
			sum+=product(temp%10,count);
			temp/=10;
		}
		return sum==n?true:false;
	}
	public static int count(int n)
	{
		int count=0;
		while(n!=0)
		{
			count++;
			n=n/10;
		}
		return count;
	}
	public static int product(int n,int count)
	{
		int res=n;
		for(int i=1;i<count;i++)
		{
			res=res*n;
		}
		return res;
	}
}
