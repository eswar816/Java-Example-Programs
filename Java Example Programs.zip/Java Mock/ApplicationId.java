class ApplicationId 
{
	public static void main(String[] args) 
	{
		int n=6444;
		System.out.println(findId(n));
	}
	public static int count(int n)
	{
		int sum=0,temp=n,rem;
		while(temp!=0)
		{
			rem=temp%10;
			temp/=10;
			sum+=rem;
		}
		return sum;
	}
	public static char findId(int n)
	{
		char c='A';int sum=0;
		if(n>=27 || n<=0)
		{
			sum=count(n);
		}
		c+=sum-1;
		return c;
	}
}
