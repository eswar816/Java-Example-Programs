class Neon 
{
	public static void main(String[] args) 
	{
		int n=99;
		if(isNeon(n))
		{
			System.out.println(n+" is a neon number");
		}
		else
		{
			System.out.println(n+" is not a neon number");
		}
		
	}
	public static boolean isNeon(int n)
	{
		int sq=n*n,rem,sum=0;
		int temp=sq;
		while(temp!=0)
		{
			rem=temp%10;
			temp/=10;
			sum+=rem;
		}
		return sum==n?true:false;
	}
}
