class Automorphic 
{
	public static void main(String[] args) 
	{
		int n=76;
		if(isAutomorphic(n))
		{
			System.out.println(n+" is an automorphic number");
		}
		else
		{
			System.out.println(n+" is not an automorphic number");
		}
	}
	public static boolean isAutomorphic(int n)
	{
		int temp=n,temp1,rem;
		rem=temp%10;
		n*=n;
		temp1=n%10;
		return rem==temp1?true:false;
	}
}

