import java.util.Scanner;
class CheckFactorial 
{
	public static void fact(int len)
	{
		
		int res=1;
		if(len==0 || len==1)
		{
			System.out.println("The factorial of" +len+ "is "+ 1);
		}
		else
		{
			for(int i=2;i<=len;i++)
			{
				res=res*i;
			}
			System.out.println("The factorial of" + len + "is "+ res);
		}
	}
}
class Factorial
{
	public static void main(String[] args) 
	{
		Scanner n=new Scanner(System.in);
		System.out.println("Enter the length");
		int len=n.nextInt();
		CheckFactorial.fact(len);
	}
}
