import java.util.Scanner;
class VowelOrConst
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a character");
		char c=sc.next().charAt(0);
		CheckVowelOrConst.check(c);
	}
}
class CheckVowelOrConst
{
	public static void check(char c) 
	{
		if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U'||c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
		{
			System.out.println(c+ " is vowel");
		}
		else
		{
			System.out.println(c+ " is consonant");
		}
	}

}
