import java.util.Scanner;
class Factor 
{
	public static void main(String[] args) 
	{
		Scanner n=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=n.nextInt();
		CheckFactor.Factors(num);
	}
}
class CheckFactor
{
	public static void Factors(int num)
	{
	System.out.println("The factors are");
	for(int i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				System.out.println(i);
			}
		}
	}
}
