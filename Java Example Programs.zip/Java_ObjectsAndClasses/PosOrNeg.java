import java.util.Scanner;
class PosOrNeg 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		CheckPosOrNeg.check(num);
	}
}
class CheckPosOrNeg
{
	public static void check(int num)
	{
		if(num>0)
		{
			System.out.println(num +" is +ve");
		}
		else
		{
			System.out.println(num +" is -ve");
		}
	}

}
