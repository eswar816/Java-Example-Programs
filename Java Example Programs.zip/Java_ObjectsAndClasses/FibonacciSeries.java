import java.util.Scanner;
class CheckFibonacciSeries 
{
	public static void check(int len)
	{
		System.out.println("The fibonacci Pattern is");
		int n1=0,n2=1;
		if(len==1)
		{
			System.out.println(n1);
		}
		else if(len==2)
		{
			System.out.println(n2);
		}
		else
		{
			System.out.println(n1);
			System.out.println(n2);
			for(int i=3;i<=len;i++)
			{
				int n3=n1+n2;
				System.out.println(n3);
				n1=n2;
				n2=n3;
			}
		}
	}
}
class FibonacciSeries
{
	public static void main(String[] args) 
	{
		Scanner n= new Scanner(System.in);
		System.out.println("Enter the length");
		int len=n.nextInt();
		CheckFibonacciSeries.check(len);
	}
}
