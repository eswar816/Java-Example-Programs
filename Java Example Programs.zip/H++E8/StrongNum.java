import java.util.Scanner;
class StrongNum 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		if(isStrong(num))
		{
			System.out.println("It is a Strong number");
		}
		else
		{
			System.out.println("It is not a Strong number");
		}
		
	}
	public static boolean isStrong(int num)
	{
		int temp=num,rem,sum=0;
		while(num>0)
		{
			sum=sum+fact(num%10);
			num/=10;
		}
		return sum==temp ?true : false;
	}
	public static int fact(int num)
	{
		int fact=1;
		for(int i=1;i<=num;i++)
		{
			fact*=i;
		}
		return fact;
	}
}
