class Automorphic 
{
	public static void main(String[] args) 
	{
		int num=12;
		if(checkAutomorphic(num))
		{
			System.out.println(num+" is a automorphic number");
		}
		else
		{
			System.out.println(num+" is not a automorphic number");
		}
	}
	public static boolean checkAutomorphic(int num)
	{
		int temp=num,rem,temp1;
		rem=temp%10;
		num=num*num;
		temp1=num%10;
		return rem==temp1?true:false;
	}
}
