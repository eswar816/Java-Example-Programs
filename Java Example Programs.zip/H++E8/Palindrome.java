import java.util.Scanner;
class Palindrome 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		if(checkPalindrome(num))
		{
			System.out.println("It is a palindrome");
		}
		else
		{
			System.out.println("It is not a palindrome");
		}

	}
	public static boolean checkPalindrome(int num)
	{
		int temp=num,rev=0,rem;
		while(num>0)
		{
			rem=num%10;
			num/=10;
			rev=rev*10+rem;
		}
		return temp==rev ? true : false;
	}
}
