import java.util.Scanner;
class MulNum 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		int num1=sc.nextInt();
		System.out.println("enter second number");
		int num2=sc.nextInt();
		System.out.println("Product of "+num1+" and "+num2+" is "+(MulNums(num1,num2)));
	}
	public static int MulNums(int num1,int num2)
	{
		int res=0;
		for(int i=0;i<num2;i++)
		{
			res+=num1;
		}
		return res;
	}
}
