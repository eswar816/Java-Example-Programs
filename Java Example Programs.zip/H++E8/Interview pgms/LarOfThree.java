import java.util.Scanner;
class LarOfThree
{
	public static void main(String[] args) 
	{
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		int[] a=new int[3];
		for(int i=0;i<3;i++)
		{
			num=Integer.parseInt(str[i]);
			a[i]=num;
		}
		System.out.println("The largest number is "+ isLarge(a));
	}
	public static int isLarge(int[] a)
	{
		if(a[0]>a[1] && a[0]>a[2])
		{
			return a[0];
		}
		else if(a[1]>a[2] && a[1]>a[0])
		{
			return a[1];
		}
		else
		{
			return a[2];
		}
	}
}
