import java.util.Scanner;
class ConsOneZero
{
	public static void main(String[] args) 
	{
		int num=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String str=sc.nextLine();
		num=Integer.parseInt(str);
		getNum(num);
	}
	public static void getNum(int num)
	{
		int temp=num,count=0,i=0;
		int[] a=new int[100];
		while(num>0)
		{
			a[i]=num%10;
			num/=10;
			count++;
			i++;
		}
		//System.out.println(count);
		getConsCount(a,count);
	}
	public static void getConsCount(int[] a,int count)
	{
		for(int i=count-1,j=count-2;i>=0&&j>=0;i-=2,j-=2)
		{
			if(a[i]==1 && a[j]==1)
			{
				System.out.println("true");
			}
			else if(a[i]==0 && a[j]==0)
			{
				System.out.println("false");
			}
		}
	}
}
