import java.util.Scanner;
class NegVal
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		System.out.println("The negative numbers are");
		for(String ss : str)
		{
			if(isNeg(Integer.parseInt(ss)))
			{
				System.out.print(ss+" ");
			}
		}
	}
	public static boolean isNeg(int a)
	{
		if(a < 0)
		{
			return true;
		}
		return false;
	}
}

