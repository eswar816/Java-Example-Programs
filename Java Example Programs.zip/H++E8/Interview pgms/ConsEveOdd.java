import java.util.Scanner;
class ConsEveOdd
{
	public static void main(String[] args) 
	{
		int num=0,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		int size=str.length;
		int[] a=new int[size];
		for(i=0;i<size;i++)
		{
			num=Integer.parseInt(str[i]);
			a[i]=num;
		}
		getEveOdd(a);
	}
	public static void getEveOdd(int[] a)
	{
		for(int i=0,j=1;i<a.length-1;i++,j++)
		{
			if(a[i]%2==0 && a[j]%2==0)
			{
				System.out.println(a[i]+","+ a[j]+" is true");
			}
			else if(a[i]%2!=0 && a[j]%2!=0)
			{
				System.out.println(a[i]+","+a[j]+" is true");
			}
			else
			{
				System.out.println(a[i]+","+a[j]+" is false");
			}
		}
	}
}
