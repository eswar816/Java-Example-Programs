import java.util.Scanner;
class Discount
{
	public static void main(String[] args) 
	{
		int num=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		for(String ss:str)
		{
			num=Integer.parseInt(ss);
			if(num<=1000)
			{
				System.out.println("The value after discount is "+num);
			}
			else if(num>1000 && num<=1500)
			{
				System.out.println("The value after discount is "+(num-getDiscount(num,10)));
			}
			else if(num>1500)
			{
				System.out.println("The value after discount is "+(num-getDiscount(num,20)));
			}
		}
	}
	public static int getDiscount(int num,int dis)
	{
		int val=0;
		val= num*dis/100;
		return val;
	}
}
