import java.util.Scanner;
class SmallestPrime
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		int[] a=new int[str.length];
		for(int i=0;i<str.length;i++)
		{
			a[i]=Integer.parseInt(str[i]);
		}
		System.out.println("The smallest prime is "+smallPrime(a));
	}
	public static int smallPrime(int[] a)
	{
		int min=a[0];
		for(int i=0;i<a.length-1;i++)
		{
			if(min>a[i+1])
			{
				if(prime(a[i+1]))
				{
					min=a[i+1];
				}
			}
		}
		return min;
	}
	public static boolean prime(int num)
	{
		if(num<=1)
		{
			return false;
		}
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
