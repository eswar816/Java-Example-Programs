import java.util.Scanner;
class CountOneZeros
{
	public static void main(String[] args) 
	{
		int num=0,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		String s=sc.nextLine();
		String[] str=s.split(" ");
		int size=str.length;
		for(i=0;i<size;i++)
		{
			getCount(Integer.parseInt(str[i]));
		}
	}
	public static void getCount(int a)
	{
		int temp=a,count=0,count1=0;
		while(a>0)
		{
			if(a%10==1)
			{
				count++;
				a/=10;
			}
			else if(a%10==0)
			{
				count1++;
				a/=10;
			}
		}
		System.out.println("THe number of 1's for "+temp+" are "+count);
		System.out.println("THe number of 0's for "+temp+" are "+count1);
		System.out.println();
	}
}
