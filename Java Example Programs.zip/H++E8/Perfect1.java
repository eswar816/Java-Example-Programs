class Perfect1  
{
	public static void main(String[] args) 
	{
		range();
	}
	public static void range()
	{
		for(int i=1;i<=10000;i++)
		{
			if(perfectRange(i))
			{
				System.out.println(i+" is a perfect number");
			}
		}
	}
	public static boolean perfectRange(int num1)
	{
		int sum=0,temp=num1;
		for(int i=1;i<num1;i++)
		{
			if(num1%i==0)
			{
				sum+=i;
			}
		}
		return temp==sum ?true :false;
	}
}
