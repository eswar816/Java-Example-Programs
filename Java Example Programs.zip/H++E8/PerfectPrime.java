class PerfectPrime
{
	public static void main(String[] args) 
	{
		range();
	}
	public static void range()
	{
		for(int i=1;i<=10000;i++)
		{
			if(perfect(i))
			{
				if(checkPrime(i))
				{
					System.out.println(i+" is a perfect prime number");
				}
			}
		}
	}
	public static boolean perfect(int num)
	{
		int sum=0,temp=num;
		for(int i=1;i<num;i++)
		{
			if(num%i==0)
			{
				sum+=i;
			}
		}
		return temp==sum ?true :false;
	}
	public static boolean checkPrime(int num)
	{
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}