class SumOfDigits 
{
	public static void main(String[] args) 
	{
		int num=123;
		System.out.println("Sum of "+num+" is "+sumOfDig(num));
	}
	public static int sumOfDig(int num)
	{
		if(num>0)
		{
			return num%10 + sumOfDig(num/10);
		}
		else
		{
			return 0;
		}
	}
}
