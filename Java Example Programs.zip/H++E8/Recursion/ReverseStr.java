class ReverseStr 
{
	public static void main(String[] args) 
	{
		String s="Hello";
		System.out.println("Reverse of "+s+" is "+reverse(s.length()-1,s));
	}
	public static String reverse(int index, String s)
	{
		if(index>=0)
		{
			return s.charAt(index)+reverse(index-1,s);
		}
		return "";
	}
}
