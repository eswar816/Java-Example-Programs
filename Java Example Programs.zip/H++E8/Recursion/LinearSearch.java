class LinearSearch 
{
	public static void main(String[] args) 
	{
		int[] a={2,3,6,7,98,56,34,9};
		int key=34;
		if(searchEle(a,0,key))
		{
			System.out.println("Element found");
		}
		else
		{
			System.out.println("Element not found");
		}
		
	}
	public static boolean searchEle(int[] a,int i,int key)
	{
		if(i>= a.length)
		{
			return false;
		}
		else if(a[i]==key)
		{
			return true;
		}
		else
		{
			return searchEle(a,i+1,key);
		}
	}
}
