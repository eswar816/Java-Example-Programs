class RotationStr
{
	public static void main(String[] args) 
	{
		String s1="IndiaUSAEngland";
		String s2="USAEnglandIndia";
		if(rotStr(s1,s2))
		{
			System.out.println("Strings are rotation of each other");
		}
		else
		{
			System.out.println("Strings are not rotation of each other");
		}
	}
	public static boolean rotStr(String s1,String s2)
	{
		String s3=s1+s2;
		if(s1.length()==s2.length() && s3.indexOf(s2)!=-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
