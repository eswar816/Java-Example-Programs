class FirstNonRepEle 
{
	public static void main(String[] args) 
	{
		String s="spiders";
		firstNonRep(s);
	}
	public static void firstNonRep(String s)
	{
		int flag=0;
		char[] ch=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<s.length();j++)
			{
				if(ch[j]!=' ')
				{
					if(ch[i]==ch[j])
					{
						ch[j]=' ';
						ch[i]=' ';
					}
				}
			}
		}
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]!=' ')
			{
				flag=1;
				System.out.println(ch[i]);
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("No unique elements");
		}
	}
}
