class Subset 
{
	public static void main(String[] args) 
	{
		int[] a={1,2,3,4,5};
		int[] b={3,4,5,9};
		if(checkSubset(a,b))
		{
			System.out.println("It is a subset");
		}
		else
		{
			System.out.println("It is not a subset");
		}
	}
	public static boolean checkSubset(int[] a,int[] b)
	{
		
		for(int i=0;i<b.length-1;i++)
		{
			int flag=0;
			for(int j=0;j<a.length-1;j++)
			{
				if(b[i]==a[j])
				{
					flag=1;
				}
				if(flag==0)
				{
					return false;
				}
			}
		}
		return true;
	}
}
