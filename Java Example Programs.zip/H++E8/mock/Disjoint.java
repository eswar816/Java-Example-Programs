class Disjoint
{
	public static void main(String[] args) 
	{
		int[] a={1,2,3,4,5};
		int[] b={6,7,8,9};
		if(checkDisjoint(a,b))
		{
			System.out.println("It is a disjoint");
		}
		else
		{
			System.out.println("It is not a disjoint");
		}
	}
	public static boolean checkDisjoint(int[] a,int[] b)
	{
		
		for(int i=0;i<a.length-1;i++)
		{
			int flag=0;
			for(int j=0;j<b.length-1;j++)
			{
				if(a[i]!=b[j])
				{
					flag=1;
				}
				if(flag==0)
				{
					return false;
				}
			}
		}
		return true;
	}
}
