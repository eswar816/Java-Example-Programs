class Automorphic 
{
	public static void main(String[] args) 
	{
		int num=5;
		if(checkAutomorphic(num))
		{
			System.out.println("It is a automorphic number");
		}
		else
		{
			System.out.println("It is not a automorphic number");
		}
	}
	public static boolean checkAutomorphic(int num)
	{
		int temp=num%10;
		int sqnum=((num*num)%10);
		if(sqnum==temp)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
