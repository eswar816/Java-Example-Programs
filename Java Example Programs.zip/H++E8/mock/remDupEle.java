class RemDupEle 
{
	public static void main(String[] args) 
	{
		String s="hello";
		remEle(s);
	}
	public static void remEle(String s)
	{
		char[] ch=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<s.length();j++)
			{
				if(ch[j]!=' ')
				{
					if(ch[i]==ch[j])
					{
						ch[j]=' ';
					}
				}
			}
		}
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]!=' ')
			{
	
				System.out.println(ch[i]);
				
			}
		}
	}
}
