class RemSpeEle 
{
	public static void main(String[] args) 
	{
		String s="welcome";
		char key='e';
		remSpeEle(s,key);
	}
	public static void remSpeEle(String s,char key)
	{
		char[] ch=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]==key)
			{
				ch[i]=' ';
			}
		}
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]!=' ')
			{
				System.out.println(ch[i]);	
			}
		}
	}
}
