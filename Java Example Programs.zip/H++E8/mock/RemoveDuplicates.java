class RemoveDuplicates 
{
	public static void main(String[] args) 
	{
		String s="Kummithi Guru Eswar Sainath REDDY";
		remDup(s);
	}
	public static void remDup(String s)
	{
		int flag=0;
		char[] ch=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<s.length();j++)
			{
				if(ch[i]==ch[j])
				{
					flag=1;
					System.out.println(ch[i]);
				}
			}
		}
		if(flag==0)
		{
			System.out.println("No duplicates");
		}
	}
}
