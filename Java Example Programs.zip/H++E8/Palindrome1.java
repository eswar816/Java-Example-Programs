class Palindrome1
{
	public static void main(String[] args) 
	{
		range();
	}
	public static void range()
	{
		for(int i=10;i<=1000;i++)
		{
			if(checkPalindrome(i))
			{
				System.out.println(i+" is a palindrome");
			}
		}
	}
	public static boolean checkPalindrome(int num)
	{
		int temp=num,rem,rev=0;
		while(num>0)
		{
			rem=num%10;
			num/=10;
			rev=rev*10+rem;
		}
		return temp==rev?true:false;
	}
}
