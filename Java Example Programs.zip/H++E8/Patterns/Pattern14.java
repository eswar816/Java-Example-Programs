class Pattern14
{
	public static void main(String[] args) 
	{
		int size=7;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=size-i;j++)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i*2-1;k++)
			{
				if(k==1 || k==i*2-1 || i==size || k==i)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}
