class Pattern21
{
	public static void main(String[] args) 
	{
		int size=9;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		int space=size/2;
		int star=1;
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=space;j++)
			{
				System.out.print(" "+" ");
			}
			for(int k=1;k<=star;k++)
			{	
				if(k==1 || k==star)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
			System.out.println();
			if(i< size/2+1)
			{
				space--;
				star+=2;
			}
			else
			{
				space++;
				star-=2;
			}
		}
	}
}