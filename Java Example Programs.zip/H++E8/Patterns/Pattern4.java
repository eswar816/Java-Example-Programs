class Pattern4
{
	public static void main(String[] args) 
	{
		int size=5;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		int s=0;
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=size-s;j++)
			{
				System.out.print("* ");
			}
			System.out.println("\n");
			s++;
		}
	}
}
