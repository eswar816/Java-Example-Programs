class Pattern10
{
	public static void main(String[] args) 
	{
		int size=5;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		int temp=1;
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(j%2==0)
				{
					System.out.print("0 ");
				}
				else
				{
					System.out.print("1 ");
				}
			}
			System.out.println("\n");
		}
	}
}
