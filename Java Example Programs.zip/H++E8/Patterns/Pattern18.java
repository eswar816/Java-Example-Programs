class Pattern18
{
	public static void main(String[] args) 
	{
		int size=5;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		for(int i=size;i>=1;i--)
		{
			for(int j=1;j<=size-i;j++)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i*2-1;k++)
			{
				if(k==1 || i==size || k==i*2-1)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}