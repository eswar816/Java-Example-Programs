class Pattern16
{
	public static void main(String[] args) 
	{
		int size=5;
		printPattern(size);
	}
	public static void printPattern(int size)
	{
		int s=0,a=0;
		char alp='A', alp1='a';
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=size-s;j++)
			{
				if(i%2==0)
				{
					if(j%2==0)
					{
						System.out.print((char)(alp+a)+" ");
						a++;
					}
					else
					{
						System.out.print((char)(alp1+a)+" ");
						a++;
					}
				}
				else
				{
					if(j%2==0)
					{
						System.out.print((char)(alp1+a)+" ");
						a++;
					}
					else
					{
						System.out.print((char)(alp+a)+" ");
						a++;
					}
				}	
			}
			System.out.println("\n");
			s++;
		}
	}
}