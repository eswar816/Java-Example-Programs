class Prog3 
{
	public static void main(String[] args) 
	{
		fact(50);
	}
	public static void fact(int num)
	{
		String res="";
		int fact=1;
		for(int i=1;i<=num;i++)
		{
			fact=fact*i;
			
		}
		res=res+fact;
		System.out.println(res);
	}
}
