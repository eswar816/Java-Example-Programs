class Demo
{
	Demo()
	{
		System.out.println("Arg constructor");
	}
	{
		System.out.println("A");
	}
	{
		System.out.println("B");
	}
}
class Pgm3
{
	public static void main(String[] args) 
	{
		Demo d=new Demo();
	}
}
