public class Pgm4 {
   {
      System.out.println("First Non-Static Block"); // first non-static block
   }
   {
      System.out.println("Second Non-Static Block"); // second non-static block
   }
   {
      System.out.println("Third Non-Static Block"); // third non-static block
   }
   Pgm4() {
      System.out.println("Execution of a Constructor"); // Constructor
   }
   public static void main(String args[]) {
      Pgm4 nsbt1 = new Pgm4();
	  System.out.println("-----------------------");
      Pgm4 nsbt2 = new Pgm4();
   }
}