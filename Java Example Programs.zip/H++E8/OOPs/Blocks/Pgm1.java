class Demo
{
	static
	{
		System.out.println("A");
	}
	static
	{
		System.out.println("B");
	}
}
class Pgm1 
{
	public static void main(String[] args) 
	{
		System.out.println("Main method");
		Demo d=new Demo();
	}
}
