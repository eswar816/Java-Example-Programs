class Pgm2
{
	static
	{
		int a=1,b=2;
		System.out.println(a+b);
	}
	static
	{
		System.out.println("B");
	}
	public static void main(String[] args) 
	{
		System.out.println("Main method");
	}
}
