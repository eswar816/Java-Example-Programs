class A
{
	int a=10,b=20;
	public void print()
	{
		System.out.println("This is parent block");
	}
}
class B extends A
{
	int x=100,y=200;
	public void disp()
	{
		System.out.println("This is child block");
	}
}
class SingleInherit 
{
	public static void main(String[] args) 
	{
		A a=new A();
		System.out.println("a.a= "+a.a);
		System.out.println("a.b= "+a.b);
		a.print();
		System.out.println();

		B b=new B();
		System.out.println("b.a= "+b.a);
		System.out.println("b.b= "+b.b);
		b.print();
		System.out.println("b.x= "+b.x);
		System.out.println("b.y= "+b.y);
		b.disp();
	}
}
