class A
{
	A()
	{
		System.out.println("A");
	}
	public void print()
	{
		System.out.println("A");
	}
}
class B extends A
{
	B()
	{
		System.out.println("B");
	}
}
class Pgm1 extends B
{
	public static void main(String[] args) 
	{
		B a=new B();
		a.print();
	}
}
