class A
{
	int x=10;
	public void print()
	{
		System.out.println("This is parent block");
	}
}
class B extends A
{
	double y=200000;
	public void disp()
	{
		System.out.println("This is child block of A");
	}
}
class C extends A
{
	long z=20000;
	public void view()
	{
		System.out.println("This is child block of A");
	}
}
class Heirarchial
{
	public static void main(String[] args) 
	{
		A a=new A();
		System.out.println("a.a= "+a.x);
		a.print();
		System.out.println();

		B b=new B();
		System.out.println("b.a= "+b.x);
		b.print();
		System.out.println("b.y= "+b.y);
		b.disp();
		System.out.println();

		C c=new C();
		System.out.println("c.x= "+c.x);
		c.print();

		System.out.println("c.z= "+c.z);
		c.view();

	}
}
