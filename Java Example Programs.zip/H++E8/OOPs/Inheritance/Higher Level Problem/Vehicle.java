class Vehicle 
{
	String model;
	String RC_num;
	int speed;
	int fuelcapacity;
	int fuelcomposition;
	
	Vehicle(String model,String RC_num,int speed,int fuelcapacity,int fuelcomposition)
	{
		this.model=model;
		this.RC_num=RC_num;
		this.speed=speed;
		this.fuelcapacity=fuelcapacity;
		this.fuelcomposition=fuelcomposition;
	}

	int fuelNeeded(int distance)
	{
		int fuelneeded=distance/this.fuelcomposition;
		return fuelneeded;
	}

	int distanceCovered(int time)
	{
		int distance=this.speed*time;
		return distance;
	}

	public void display()
	{
		System.out.println("Model= "+model);
		System.out.println("Registration number= "+RC_num);
		System.out.println("Speed= "+speed);
		System.out.println("FuelCapacity= "+fuelcapacity);
		System.out.println("Fuelcomposition= "+fuelcomposition);
	}
	
}
