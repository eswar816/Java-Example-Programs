class Transport 
{
	public static void main(String[] args) 
	{
		Truck t=new Truck("Benz2020","APXXXX02",30,70,10,5000);
		t.display();

		Bus b=new Bus("volvo2019","KAXXXX12",110,100,30,52);
		b.display();
	}
}
