class Bus extends Vehicle
{
	int no_of_pass;

	Bus(String model,String RC_num,int speed,int fuelcapacity,int fuelcomposition,int no_of_pass)
	{
		super(model,RC_num,speed,fuelcapacity,fuelcomposition);
		this.no_of_pass=no_of_pass;
	}

	public void display()
	{
		System.out.println("-----------------------");
		super.display();
		System.out.println("Fuelneeded= "+super.fuelNeeded(500));
		System.out.println("DistanceCovered= "+super.distanceCovered(8));
		System.out.println("Number of passengers= "+no_of_pass);

	}
}
