class Truck extends Vehicle
{
	int weigthlimit;

	Truck(String model,String RC_num,int speed,int fuelcapacity,int fuelcomposition,int weigthlimit)
	{
		super(model,RC_num,speed,fuelcapacity,fuelcomposition);
		this.weigthlimit=weigthlimit;
	}

	public void display()
	{
		System.out.println("-----------------------");
		super.display();
		System.out.println("Fuelneeded= "+super.fuelNeeded(20));
		System.out.println("DistanceCovered= "+super.distanceCovered(1));
		System.out.println("Weigthlimit= "+weigthlimit);

	}
}
