class A
{
	int x=10;
	public void print()
	{
		System.out.println("This is parent block");
	}
}
class B extends A
{
	double y=200000;
	public void print(int a)
	{
		System.out.println("This is child block of A");
	}
}
class C extends B
{
	char z='A';
	public void disp()
	{
		System.out.println("This is child block of B");
	}
}
class Multilevel
{
	public static void main(String[] args) 
	{
		A a=new A();
		System.out.println("a.a= "+a.x);
		a.print();
		System.out.println();

		B b=new B();
		System.out.println("b.a= "+b.x);
		b.print();
		System.out.println("b.y= "+b.y);
		b.print(10);
		System.out.println();

		C c=new C();
		System.out.println("c.x= "+c.x);
		c.print();

		System.out.println("c.y= "+c.y);
		c.print(10);

		System.out.println("c.z= "+c.z);
		c.disp();

	}
}
