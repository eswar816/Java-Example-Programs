class Student
{
	String name;
	String id;
	Double marks;
	
	Student(String name,String id,double marks)
	{
		this.name=name;
		this.id=id;
		this.marks=marks;
	}
	public void dispDetails()
	{
		String name="Bob";
		String id="s1";
		double marks=79.07;

		System.out.println("Name= "+this.name);
		System.out.println("Id= "+this.id);
		System.out.println("Marks= "+this.marks);
	}
}
class Pgm2
{
	public static void main(String[] args) 
	{
		Student s1=new Student("Sai","s1",86.98);
		Student s2=new Student("John","s2",78.00);
		Student s3=new Student("Ruby","s3",67.98);

		System.out.println();
		s1.dispDetails();

		System.out.println();
		s2.dispDetails();

		System.out.println();
		s3.dispDetails();

	}
}
