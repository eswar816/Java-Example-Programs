class A
{
	public int x=10,y=20;

	public void print()
	{
		System.out.println("In super class");
	}
}
class B extends A
{
	public int x=100,y=200;

	public void disp()
	{
		int x=1000,y=2000;
		System.out.println("X= "+x);
		System.out.println("Y= "+y);

		System.out.println("X= "+this.x);
		System.out.println("Y= "+this.y);

		System.out.println();

		System.out.println("X= "+super.x);
		System.out.println("Y= "+super.y);
	}
}
class Pgm3
{
	public static void main(String[] args) 
	{
		B b=new B();
		b.print();
		b.disp();
	}
}
