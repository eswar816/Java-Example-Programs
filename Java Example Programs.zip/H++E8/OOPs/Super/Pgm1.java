class A
{
	public int x=10,y=20;

	public void print()
	{
		System.out.println("In super class");
	}
}
class B extends A
{
	public int x=100,y=200;

	public void disp()
	{
		int x=1000,y=2000;
		System.out.println("X= "+x);//1000
		System.out.println("Y= "+y);//2000

		System.out.println();

		System.out.println("X= "+this.x);//100
		System.out.println("Y= "+this.y);//200

		System.out.println();

		System.out.println("X= "+super.x);//10
		System.out.println("Y= "+super.y);//20
	}
}
class Pgm1
{
	public static void main(String[] args) 
	{
		B b=new B();
		b.print();
		b.disp();
	}
}
