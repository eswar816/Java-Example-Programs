class A
{
	int x,y;
	A(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	public void add(int x,int y)
	{
		System.out.println(x+y);
	}	
}
class B extends A
{
	B(int x,int y)
	{
		super(x,y);
	}
}
class Pgm2
{
	public static void main(String[] args) 
	{
		B b=new B(5,6);
	}
}
