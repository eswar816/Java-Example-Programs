class A
{
	A()
	{
		
		System.out.println("Calling empty constructor");
	}
	A(float a)
	{
		this();
		System.out.println("Calling float constructor");
	}
}
class B extends A
{
	B(double d)
	{
		super(10.5f);
		System.out.println("Calling double constructor");
	}
}
class C extends B
{
	C(int a)
	{
		super(30000.00);
		System.out.println("Calling int constructor");
	}
}
class Pgm1 
{
	public static void main(String[] args) 
	{
		C c=new C(10);
	}
}
