class A
{
	A()
	{
		this(10,78.09);
		System.out.println("Calling empty constructor");
	}
	A(int a)
	{
		this();
		System.out.println("Calling int constructor");
	}
	A(double a)
	{
		System.out.println("Calling double constructor");
	}
	A(int a,double b)
	{
		this(79.45);
		System.out.println("Calling int/double constructor");
	}
}
class Pgm1 
{
	public static void main(String[] args) 
	{
		A a=new A(10);
	}
}
