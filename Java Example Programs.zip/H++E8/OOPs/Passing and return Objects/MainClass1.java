class Demo
{
	public void Print()
	{
		System.out.println("Hello JSP");
	}
}
class Test
{
	public Demo getInstance()
	{
		return new Demo();
	}
}
class MainClass1
{
	public static void main(String[] args) 
	{
		new Test().getInstance().Print();
	}
}
