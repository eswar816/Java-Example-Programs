public class Book
{
	private String author;
	private String book_edition;
	private double cost;

	public Book(String author,String book_edition,double cost)
	{
		this.author=author;
		this.book_edition=book_edition;
		this.cost=cost;
	}

	public String getauthor()
	{
		return author;
	}
	public String getbook_edition()
	{
		return book_edition;
	}
	public double getcost()
	{
		return cost;
	}
	public void setauthor(String author)
	{
		this.author=author;
	}
	public void setbook_edition(String book_edition)
	{
		this.book_edition=book_edition;
	}
	public void setcost(double cost)
	{
		this.cost=cost;
	}
}
class mainclass
{
	public static void main(String[] args) 
	{
		Book b=new Book("Sai","ED-1",2000.00);
		System.out.println("Author: "+b.getauthor());
		System.out.println("BookEdition: "+b.getbook_edition());
		System.out.println("Cost: "+b.getcost());
	}
}
