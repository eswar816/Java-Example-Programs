class Test
{
	public static void main(int[] args, int m)
	{
		System.out.println("i = "+m);
		for(int i = 0 ; i < args.length; i++)
		{
			System.out.println(args[i]);
		}
	}
	public static void main(char[] args, char c)
	{
		System.out.println("c = "+c);
		for(int i = 0 ; i < args.length; i++)
		{
			System.out.println(args[i]);
		}
	}
	public static void main(String[] args, String s)
	{
		System.out.println("s = "+s);
		for(int i = 0 ; i < args.length; i++)
		{
			System.out.println(args[i]);
		}
	}
	public static void main(double[] args, double d)
	{
		System.out.println("d = "+d);
		for(int i = 0 ; i < args.length; i++)
		{
			System.out.println(args[i]);
		}
	}
}

class MainOverloading1
{
	public static void main(String[] args) 
	{
		Test t=new Test();
		int m=1;
        int[] a={1,2,3,4,5};
		char j='a';
        char[] b={'A','B','C','D'};
		String k="Eswar";
        String[] c={"Hi","Hello","Welcome"};
		double l=10.00;
        double[] d={10.00,11.00,12.00};
        t.main(a,m);
		System.out.println("----------");
        t.main(b,j);
		System.out.println("----------");
        t.main(d,l);
		System.out.println("----------");
        t.main(c,k);
	}
}