class Test{
    
     public static void main(int[] args){
       for(int i=0;i<args.length;i++)
       {
           System.out.println(args[i]);
       }
     }
     
      public static void main(char[] args){
        for(int i=0;i<args.length;i++)
       {
           System.out.println(args[i]);
       }
     }
     
      public static void main(double[] args){
        for(int i=0;i<args.length;i++)
       {
           System.out.println(args[i]);
       }
     }
    
     public static void main(String []args){
      for(int i=0;i<args.length;i++)
       {
           System.out.println(args[i]);
       }
     }
}
public class MainOverloading
{
     public static void main(String []args){
        Test t=new Test();
        int[] a={1,2,3,4,5};
        char[] b={'A','B','C','D'};
        String[] c={"Hi","Hello","Welcome"};
        double[] d={10.00,11.00,12.00};
        t.main(a);
		System.out.println("----------");
        t.main(b);
		System.out.println("----------");
        t.main(d);
		System.out.println("----------");
        t.main(c);
     }
}