import java.util.*;
class DispSumNums 
{
	public static void main(String[] args) 
	{
		for(int i=0;i<args.length;i++)
		{
			SumNums(args[i]);
		}
	}
	public static void SumNums(String s)
	{
		int sum=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)>='1' && s.charAt(i)<='9')
			{
				sum+=((int)(s.charAt(i))-48);
			}
		}
		System.out.print(sum+" ");
	}
}
