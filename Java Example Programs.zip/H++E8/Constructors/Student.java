class Student 
{
	String name;
	String id;
	int marks;
	Student()
	{
	}
	Student(String name,String id,int marks)
	{
		this.name=name;
		this.id=id;
		this.marks=marks;
	}
	Student(String name,String id)
	{
		this.name=name;
		this.id=id;
	}
	/*Student(String name,int marks)
	{
		this.name=name;
		this.marks=marks;
	}
	Student(String id,int marks)
	{
		this.id=id;
		this.marks=marks;
	}*/
	public static void main(String[] args) 
	{
		Student s1=new Student();
		Student s2=new Student("Eswar","1XXCS00",87);
		Student s3=new Student("Eswar","1XXCS00");
		//Student s4=new Student("Eswar",87);
		//Student s5=new Student("1XXCS00",87);
		System.out.println("Name= "+s1.name);
		System.out.println("Id= "+s1.id);
		System.out.println("Marks= "+s1.marks);

		System.out.println("Name= "+s2.name);
		System.out.println("Id= "+s2.id);
		System.out.println("Marks= "+s2.marks);

		/*System.out.println("Name= "+s3.name);
		System.out.println("Id= "+s3.id);

		System.out.println("Name= "+s4.name);
		System.out.println("Marks= "+s4.marks);

		System.out.println("Id= "+s5.id);
		System.out.println("Marks= "+s5.marks);*/
	}
}
