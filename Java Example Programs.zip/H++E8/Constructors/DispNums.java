import java.util.*;
class DispNums 
{
	public static void main(String[] args) 
	{
		for(int i=0;i<args.length;i++)
		{
			OnlyNums(args[i]);
		}
	}
	public static void OnlyNums(String s)
	{
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)>='1' && s.charAt(i)<='9')
			{
				System.out.print(s.charAt(i));
			}
		}
		System.out.print(" ");
	}
}
