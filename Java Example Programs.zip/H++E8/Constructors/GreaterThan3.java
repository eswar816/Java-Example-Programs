import java.util.*;
class GreaterThan3 
{
	public static void main(String[] args) 
	{
		if(args.length==3)
		{
			int num1=Integer.parseInt(args[0]);
			int num2=Integer.parseInt(args[1]);
			int num3=Integer.parseInt(args[2]);

			System.out.println("Greatest number is "+greater(num1,num2,num3));
		}
		else
		{
			System.out.println("Enter 3 numbers please......");
		}
		
	}

	public static int greater(int a,int b,int c)
	{
		if(a>b && a>c)
		{
			return a;
		}
		else if(b>c && b>a)
		{
			return b;
		}
		else if(c>a && c>b)
		{
			return c;
		}
		else
		{
			return -1;
		}
	}
}
