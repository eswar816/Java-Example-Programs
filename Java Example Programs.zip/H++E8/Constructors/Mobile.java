import java.util.*;
class Mobile
{
	String name;
	String color;
	double price;

	public Mobile(String name,String color,double price)
	{
		this.name=name;
		this.color=color;
		this.price=price;
	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		String name=sc.next();
		String color=sc.next();
		double price=sc.nextDouble();
		Mobile M1=new Mobile(name,color,price);

		System.out.println("Name :"+M1.name);
		System.out.println("Color :"+M1.color);
		System.out.println("Price :"+M1.price);
		System.out.println();

		name=sc.next();
		color=sc.next();
		price=sc.nextDouble();
		Mobile M2=new Mobile(name,color,price);

		System.out.println("Name :"+M2.name);
		System.out.println("Color :"+M2.color);
		System.out.println("Price :"+M2.price);
		System.out.println();

		name=sc.next();
		color=sc.next();
		price=sc.nextDouble();
		Mobile M3=new Mobile(name,color,price);

		System.out.println("Name :"+M3.name);
		System.out.println("Color :"+M3.color);
		System.out.println("Price :"+M3.price);
	}
}
