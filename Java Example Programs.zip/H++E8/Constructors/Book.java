import java.util.*;
class Book
{
	String name,author,publisher;
	double price;


	public Book(String name,String author,double price,String publisher)
	{
		this.name=name;
		this.author=author;
		this.price=price;
		this.publisher=publisher;
	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		String name=sc.next();
		String author=sc.next();
		double price=sc.nextDouble();
		String publisher=sc.next();
		Book B1=new Book(name,author,price,publisher);

		System.out.println("Name :"+B1.name);
		System.out.println("Author :"+B1.author);
		System.out.println("Price :"+B1.price);
		System.out.println("Publisher :"+B1.publisher);
		System.out.println();

		name=sc.next();
		author=sc.next();
		price=sc.nextDouble();
		publisher=sc.next();
		Book B2=new Book(name,author,price,publisher);

		System.out.println("Name :"+B2.name);
		System.out.println("Author :"+B2.author);
		System.out.println("Price :"+B2.price);
		System.out.println("Publisher :"+B2.publisher);
		System.out.println();

		name=sc.next();
		author=sc.next();
		price=sc.nextDouble();
		publisher=sc.next();
		Book B3=new Book(name,author,price,publisher);

		System.out.println("Name :"+B3.name);
		System.out.println("Author :"+B3.author);
		System.out.println("Price :"+B3.price);
		System.out.println("Publisher :"+B3.publisher);
	}
}
