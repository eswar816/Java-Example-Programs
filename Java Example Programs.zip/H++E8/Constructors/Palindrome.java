class Palindrome 
{
	public static void main(String[] args) 
	{
		for(int i=0;i<args.length;i++)
		{
			if(checkPalindrome(args[i]))
			{
				System.out.print(args[i]+" ");
			}
		}
		
	}
	public static boolean checkPalindrome(String s)
	{
		char[] ch=s.toCharArray();
		for(int i=0;i<ch.length/2;i++)
		{
			if(ch[i]!=ch[ch.length-1-i])
			{
				return false;
			}
		}
		return true;
	}
}
