import java.util.Scanner;
class FirstUniqueEle 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		firstUniqueEle(a);
	}
	public static void firstUniqueEle(int[] a)
	{
		int i,flag=0;
		for(i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j]!=-1)
				{
					if(a[i]==a[j])
					{
						a[j]=-1;
						a[i]=-1;
					}
				}
			}
		}
		System.out.println("Unique array elements");
		for(i=0;i<a.length;i++)
		{
			if(a[i]!=-1)
			{
				flag=1;
				System.out.println(a[i]);
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("No unique elements");
		}
	}
}
