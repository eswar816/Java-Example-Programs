import java.util.Scanner;
class LinearSearchString
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		String[] a=new String[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.next();
		}
		System.out.println("enter the key to be searched");
		String key=sc.next();
		Search(a,key);
	}
	public static void Search(String[] a,String key)
	{
		boolean flag=false;
		for(int i=0;i<a.length;i++)
		{
			if(key.equals(a[i]))
			{
				System.out.println("Key is found at  the  pos "+ (i+1));
				flag=true;
				break;
			}
		}
		if(!flag)
		{
			System.out.println("Key is not found");
		}
	}
}