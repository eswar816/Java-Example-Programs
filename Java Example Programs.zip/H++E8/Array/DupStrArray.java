import java.util.Scanner;
class DupStrArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		String[] a=new String[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.next();
		}
		dupStrVal(a);
	}
	public static void dupStrVal(String[] a)
	{
		int i;
		System.out.println("Duplicate string elements");
		for(i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(!(a[j].equals(" ")))
				{
					if(a[i].equals(a[j]))
					{
						a[j]=" ";
					}
				}
			}
		}
		for(i=0;i<a.length;i++)
		{
			if(!(a[i].equals(" ")))
			{
				System.out.println(a[i]);
			}
		}
	}
}
