import java.util.Scanner;
class FindMissEle
{
	public static void main(String[] args) 
	{
		int[] x=intArray1();
		findEle(x);
	}
	public static int[] intArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter the array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();;
		}
		return a;
	}
	public static void findEle(int[] a)
	{
		System.out.println("The array values are");
		int diff=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(a[i]-i !=diff)
			{
				while(diff<a[i]-i)
				{
					System.out.println(diff+i);
					diff++;
				}
			}
		}
	}
}
