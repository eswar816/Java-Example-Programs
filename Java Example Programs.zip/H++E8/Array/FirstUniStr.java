import java.util.Scanner;
class FirstUniStr
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		String[] a=new String[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.next();
		}
		firUniStr(a);
	}
	public static void firUniStr(String[] a)
	{
		   for(int i=0;i< a.length ; i++)
		{
		     int flag = 0;
			   for(int j=i+1;j< a.length ; j++)
				{
				   
				   if(a[i].equals(a[j]))
			       {
			         flag=1;
					 
				   }
				 }
				
				if(flag==1)
				{
				   System.out.println("the first duplicate string is " + a[i] );
				   break;
				}
		   }
		/**int i,j,flag=0;;
		System.out.println("First Duplicate element is");
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i].equals(a[j]))
				{
					flag=1;
					/System.out.println(a[i]);
					System.exit(0);
				}
			}
			if(flag==0)
			{
				System.out.println(a[j]);
				System.exit(0);
			}
		}
		if(flag==0)
			{
				System.out.println("No First Duplicate elements");
			}**/
	}
}
