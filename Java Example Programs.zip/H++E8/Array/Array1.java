import java.util.Scanner;
class Array1 
{
	public static void main(String[] args) 
	{
		String[] s=stringArray1();
		printArray(s);
	}
	public static String[] stringArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		String[] s=new String[length];
		System.out.println("Enter the characters");
		for(int i=0;i<s.length;i++)
		{
			s[i]=sc.next();;
		}
		return s;
	}
	public static void printArray(String[] s)
	{
		System.out.println("Strings are");
		for(String str:s)
		{
			System.out.println(str);
		}
	}
}
