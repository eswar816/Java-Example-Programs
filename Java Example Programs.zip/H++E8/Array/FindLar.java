import java.util.Scanner;
class FindLar 
{
	public static void main(String[] args) 
	{
		int[] x=intArray1();
		findLarEle(x);
	}
	public static int[] intArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter the characters");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();;
		}
		return a;
	}
	public static void findLarEle(int[] a)
	{
		int smax=0,fmax=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>fmax)
			{
				smax=fmax;
				fmax=a[i];
			}
			else if(a[i]>smax && a[i]!=fmax)
			{
				smax=a[i];
			}
		}
	System.out.println("First maximum num is "+fmax+"\nSecond maximum num is "+smax);
	}
}
