import java.util.Scanner;
class FindSmallAndLar
{
	public static void main(String[] args) 
	{
		int[] x=intArray1();
		findSmallEle(x);
		findLarEle(x);
	}
	public static int[] intArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter the characters");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();;
		}
		return a;
	}
	public static void findSmallEle(int[] a)
	{
		int small=999;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<small)
			{
				small=a[i];
			}
		}
	System.out.println("Small number is "+small);
	}
	public static void findLarEle(int[] a)
	{
		int lar=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>lar)
			{
				lar=a[i];
			}
		}
	System.out.println("Large number is "+lar);
	}
}
