import java.util.Scanner;
class SmallPrimeArray 
{
	public static void main(String[] args) 
	{
		int sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println("Small prime number is "+smallPrime(a));
	}
	public static int smallPrime(int[] a)
	{
		int min=a[0];
		for(int i=0;i<a.length-1;i++)
		{
			if(min>a[i+1])
			{
				if(prime(a[i+1]))
				{
					min=a[i+1];
				}
			}
		}
		return min;
	}
	public static boolean prime(int num)
	{
		if(num<=1)
		{
			return false;
		}
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
