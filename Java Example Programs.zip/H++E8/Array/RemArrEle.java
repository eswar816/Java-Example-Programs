import java.util.*;
class RemArrEle
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array size");
		int l1=sc.nextInt();
		int[] a=new int[l1];
		System.out.println("Enter array values");
		for(int i=0;i<l1;i++)
		{
			a[i]=sc.nextInt();
		}
		int pos=3;
		remEle(a,pos);
	}
	public static void remEle(int[] a,int pos)
	{
		int[] b=new int[a.length-1];
		int i;
		for(i=0;i<pos;i++)
		{
			b[i]=a[i];
		}
		//i++;
		for(;i<b.length;i++)
		{
			b[i]=a[i+1];
		}
		System.out.println("The array values are");
		for(i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	}
}
