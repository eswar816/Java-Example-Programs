import java.util.Scanner;
class LinearSearch
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the key to be searched");
		int key=sc.nextInt();
		LinearSearch(a,key);
	}
	public static void LinearSearch(int[] a,int key)
	{
		boolean flag=false;
		for(int i=0;i<a.length;i++)
		{
			if(key==a[i])
			{
				System.out.println("Key is found at " + (i+1) + " the " + " pos ");
				flag=true;
				break;
			}
		}
		if(!flag)
		{
			System.out.println("Key is not found");
		}
	}
}