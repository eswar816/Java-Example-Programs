import java.util.Scanner;
class DelComArrayEle 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array1");
		int l1=sc.nextInt();
		int[] a=new int[l1];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the length of array2");
		int l2=sc.nextInt();
		int[] b=new int[l2];
		System.out.println("enter the array elements");
		for(int i=0;i<b.length;i++)
		{
			b[i]=sc.nextInt();
		}
		delComEle(a,b,l1,l2);
	}
	public static void delComEle(int[] a,int[] b,int l1,int l2)
	{
		int i,j,flag=0;
		System.out.println("Unique array elements");
		for(i=0;i<l1;i++)
		{
			if(a[i]!=-1)
			{
				for(j=0;j<l2;j++)
				{
					if(a[i]==b[j])
					{
						a[i]=-1;
						b[j]=-1;
					}
					
				}
			}
		}
		for(i=0;i<l1;i++)
		{
			if(a[i]!=-1)
			{
				System.out.println(a[i]);
			}
		}
		for(i=0;i<l2;i++)
		{
			if(b[i]!=-1)
			{
				System.out.println(b[i]);
			}
		}
		
	}
}
