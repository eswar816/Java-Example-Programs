import java.util.Scanner;
class RevArrayString
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length");
		int length=sc.nextInt();
		String[] a=new String[length];
		System.out.println("Enter array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.next();
		}
		reverseString(a);
		System.out.println("Reversed array is");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static String[] reverseString(String[] a)
	{
		String temp="";
		for(int i=0;i<a.length/2;i++)
		{
			temp=a[i];
			a[i]=a[a.length-1-i];
			a[a.length-1-i]=temp;
		}
		return a;
	}
}
