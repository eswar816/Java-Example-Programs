import java.util.Scanner;
class FindMissEle1
{
	public static void main(String[] args) 
	{
		int[] x=intArray1();
		findEle1(x);
	}
	public static int[] intArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter the array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();;
		}
		return a;
	}
	public static void findEle1(int[] a)
	{
		int temp=0;
		System.out.println("The missing array values are");
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		for(int i=0;i<a.length-1;i++)
		{
			int j=i+1;
			if((a[i]+1)!=a[j])
			{
				System.out.println(a[i]+1);
			}
		}
	}
}
