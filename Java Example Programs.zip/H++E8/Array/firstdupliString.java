class firstdupliString
{
	public static void main(String[] args) 
	{
		String[]a={"bb","cc","dd","ee","aa","dd","aa"};
		firstDupliString(a);
		
	}
	public static void firstDupliString(String[]a)
	{
	   for(int i=0;i< a.length ; i++)
		{
		     int count = 1;
			   for(int j=i+1;j< a.length ; j++)
				{
				   
				   if(a[i]==a[j])
			       {
			         count++;
					 
				   }
				 }
				
				if(count>1)
				{
				   System.out.println("the first duplicate string is " + a[i] );
				   break;
				}
		   }
			
		 }
	
}
