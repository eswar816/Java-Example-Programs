import java.util.Scanner;
class LinearSearchChar
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		char[] a=new char[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.next().charAt(0);
		}
		System.out.println("enter the key to be searched");
		char key=sc.next().charAt(0);
		Search(a,key);
	}
	public static void Search(char[] a,char key)
	{
		boolean flag=false;
		for(int i=0;i<a.length;i++)
		{
			if(key==a[i])
			{
				System.out.println("Key is found at " + (i+1) + " the " + " pos ");
				flag=true;
				break;
			}
		}
		if(!flag)
		{
			System.out.println("Key is not found");
		}
	}
}