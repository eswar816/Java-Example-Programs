import java.util.*;
class ArrayZigZag 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array1 size");
		int l1=sc.nextInt();
		int[] a=new int[l1];
		System.out.println("Enter array1 values");
		for(int i=0;i<l1;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Enter array2 size");
		int l2=sc.nextInt();
		int[] b=new int[l2];
		System.out.println("Enter array2 values");
		for(int i=0;i<l2;i++)
		{
			b[i]=sc.nextInt();
		}
		zigzag(a,b,l1,l2);
	}
	public static void zigzag(int[] a,int[] b,int l1,int l2)
	{
		int size=a.length+b.length;
		int[] res=new int[size];
		int i=0,j=0,k=0;
		while(i<l1 && j<l2)
		{
			res[k++]=a[i++];
			res[k++]=b[j++];
		}
		while(i<l1)
		{
			res[k++]=a[i++];
		}
		while(j<l2)
		{
			res[k++]=b[j++];
		}
		System.out.println("Result array values are");
		for(i=0;i<size;i++)
		{
			System.out.println(res[i]);	
		}
	}
}
