import java.util.Scanner;
class PrimeNums 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		prime1(a);
	}
	public static void prime1(int[] a)
	{
		System.out.println("Prime array values are");
		for(int i=0;i<a.length;i++)
		{
			if(prime(a[i]))
			{
				System.out.println(a[i]);
			}
		}
	}
	public static boolean prime(int num)
	{
		if(num<=1)
		{
			return false;
		}
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
