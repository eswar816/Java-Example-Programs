import java.util.Scanner;
class PrimeArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		prime(a);
	}
	public static void prime(int[] a)
	{
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			if(checkPrime(a[i]))
			{
				sum+=a[i];
			}
		}
		System.out.println("Sum of all prime numbers in array are "+sum);
	}
	public static boolean checkPrime(int num)
	{
		if(num<=1)
		{
			return false;
		}
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
