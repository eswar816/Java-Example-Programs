import java.util.Scanner;
class UniqueEleArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		uniqueArray(a);
	}
	public static void uniqueArray(int[] a)
	{
		int i;
		for(i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j]!=-1)
				{
					if(a[i]==a[j])
					{
						a[j]=-1;
						a[i]=-1;
					}
				}
			}
		}
		System.out.println("Unique array elements");
		for(i=0;i<a.length;i++)
		{
			if(a[i]!=-1)
			{
				System.out.println(a[i]);
			}
		}
	}
}
