import java.util.Scanner;
class SearchCount
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length of array");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("enter the array elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the key to be searched");
		int key=sc.nextInt();
		LinearSearch(a,key);
	}
	public static void LinearSearch(int[] a,int key)
	{
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			if(key==a[i])
			{
				count++;
			}
		}
		System.out.println("The number of occurences are "+count);
	}
}