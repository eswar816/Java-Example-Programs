import java.util.Scanner;
class FindSumPairs
{
	public static void main(String[] args) 
	{
		int[] x=intArray1();
		findPairs(x);
	}
	public static int[] intArray1()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length ");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter the array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();;
		}
		return a;
	}
	public static void findPairs(int[] a)
	{
		int count=0,sum=11;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==sum)
				{
					count++;
				}
			}
		}
	System.out.println("The number of pairs are "+count);
	}
}
