import java.util.Scanner;
class PerfectArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length");
		int length=sc.nextInt();
		int[] a=new int[length];
		System.out.println("Enter array values");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		perfect(a);
	}
	public static void perfect(int[] a)
	{
		for(int i=0;i<a.length-1;i++)
		{
			if(checkPerfect(a[i]))
			{
				System.out.println(a[i]+" is a perfect number");
			}
		}
	}
	public static boolean checkPerfect(int num)
	{
		int sum=0;
		for(int i=1;i<num;i++)
		{
			if(num%i==0)
			{
				sum+=i;
			}
		}
		return sum==num? true : false;
	}
}
