class Splitpgm 
{
	public static void main(String[] args) 
	{
		String s="Hello friends";
		split(s);
		
	}
	public static void split(String s)
	{
		String[] str=s.split(" ");
		for(String s1 : str)
		{
			System.out.print(reverse(s1+" "));
		}
	}
	public static String reverse(String s1)
	{
		String s2="";
		for(int i=s1.length()-1;i>=0;i--)
		{
			s2+=s1.charAt(i);
		}
		return s2;
	}
}
