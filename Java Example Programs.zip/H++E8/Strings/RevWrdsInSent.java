class RevWrdsInSent
{
	public static void main(String[] args) 
	{
		String s="Welcome to java class";
		System.out.println(s);
		getWords(s);
	}
	public static String[] breakStr(String s)
	{
		String[] str=new String[getCountSpace(s)+1];
		String temp="";
		int j=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!=' ')
			{
				temp+=s.charAt(i);
			}
			else
			{
				str[j]=temp;
				j++;
				temp="";
			}
		}
		str[j]=temp;
		return str;
	}
	public static int getCountSpace(String s)
	{
		int count=0,i=0;
		while(i<s.length())
		{
			if(s.charAt(i)==' ')
			{
				count++;
			}
			i++;
		}
		return count;
	}
	public static void getWords(String s)
	{
		String[] str=breakStr(s);
		for(int i=0;i<str.length;i++)
		{
			str[i]=revWords(str[i]);
		}
		for(String s1:str)
		{
			System.out.print(s1+" ");
		}
	}
	public static String revWords(String s)
	{
		String s1="";
		for(int i=s.length()-1;i>=0;i--)
		{
			s1+=s.charAt(i);
		}
		return s1;
	}
}
