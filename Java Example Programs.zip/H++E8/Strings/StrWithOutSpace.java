import java.util.*;
class StrWithOutSpace 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.nextLine();
		removeSpace(s);
		//System.out.println("String without spaces is "+removeSpace(s));		
	}
	public static void removeSpace(String s)
	{
		char[] ch=s.toCharArray();
		String s2="";
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]!=' ')
			{
				s2+=ch[i];
			}
		}
		System.out.println("String without spaces is "+s2);	
		//return nospace;
	}
}