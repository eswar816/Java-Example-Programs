class Panagram
{
	public static void main(String[] args) 
	{
		String s="The quick brown fox jumps over the lazy dog";
		if(Panagram(s))
		{
			System.out.println("Panagram");
		}
		else
		{
			System.out.println("Not panagram");
		}
	}
	public static boolean Panagram(String s)
	{
		boolean[] b=new boolean[26];
		int index=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)>='A' && s.charAt(i)<='Z')
			{
				index=s.charAt(i)-'A';
			}
			else if(s.charAt(i)>='a' && s.charAt(i)<='z')
			{
				index=s.charAt(i)-'a';
			}
			b[index]=true;
		}
		for(int i=0;i<26;i++)
		{
			if(b[i]!=true)
			{
				return false;
			}
		}
		return true;
	}
	
}
