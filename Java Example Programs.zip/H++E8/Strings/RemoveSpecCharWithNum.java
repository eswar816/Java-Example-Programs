import java.util.*;
class RemoveSpecCharWithNum
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		System.out.println("String without special chracter is "+removeSpecCharWithNum(s));		
	}
	public static String removeSpecCharWithNum(String s)
	{
		char[] ch=s.toCharArray();
		String nospecial="";
		for(char c:ch)
		{
			if((c>='A' && c<='Z') || (c>='a' && c<='z'))
			{
				nospecial+=c;
			}
		}
		return nospecial;
	}
}