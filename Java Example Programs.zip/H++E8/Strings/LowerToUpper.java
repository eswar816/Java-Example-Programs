import java.util.*;
class LowerToUpper
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		System.out.println("String in upper case "+upperCase(s));		
	}
	public static String upperCase(String s)
	{
		char[] ch=s.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			ch[i]=(char)(ch[i]-32);
		}
		return new String(ch);
	}
}