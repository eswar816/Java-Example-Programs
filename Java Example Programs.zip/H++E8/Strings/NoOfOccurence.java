class NoOfOccurence 
{
	public static void main(String[] args) 
	{
		String s="sainath";
		countOcc(s);
	}
	public static void countOcc(String s)
	{
		char[] ch=s.toCharArray();
		int i=0,j=0;
		for(i=0;i<ch.length;i++)
		{
			int count=1;
			for(j=i+1;j<ch.length;j++)
			{
				if(ch[i]==ch[j])
				{
					count++;
					ch[j]=' ';
				}
			}
			if(ch[i]!=' ')
			{
				System.out.println(ch[i]+" - "+count);
			}
			
		}
	}
}
