import java.util.*;
class ConvertToNum
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		System.out.println("String into numbers  "+convertToNum(s));		
	}
	public static int convertToNum(String s)
	{
		char[] ch=s.toCharArray();
		int num=0;
		for(int i=0;i<ch.length;i++)
		{
			num=num*10+ch[i]-48;
		}
		return num;
	}
}