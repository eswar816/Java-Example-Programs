import java.util.*;
class RemoveSpecChar
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		System.out.println("String without special chracter is "+removeSpecChar(s));		
	}
	public static String removeSpecChar(String s)
	{
		char[] ch=s.toCharArray();
		String nospecial="";
		for(char c:ch)
		{
			if((c>='A' && c<='Z') || (c>='a' && c<='z') || (c>='0' && c<='9'))
			{
				nospecial+=c;
			}
		}
		return nospecial;
	}
}