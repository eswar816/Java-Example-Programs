import java.util.*;
class ConvertToInitcap
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.nextLine();
		System.out.println("String into numbers  "+toInitcap(s));		
	}
	public static String toInitcap(String s)
	{
		char[] ch=s.toCharArray();
		ch[0]=(char)(ch[0]-32);
		for(int i=1;i<ch.length;i++)
		{
			if(ch[i]==' ')
			{
				ch[i+1]=(char)(ch[i+1]-32);
			}
		}
		return new String(ch);
	}
}