import java.util.Scanner;
class Palindrome 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		if(checkPalindrome(s))
		{
			System.out.println(s+" is a palindrome");
		}
		else
		{
			System.out.println(s+" is not a palindrome");
		}
	}
	public static boolean checkPalindrome(String s)
	{
		char[] ch=s.toCharArray();
		for(int i=0;i<ch.length/2;i++)
		{
			if(ch[i]!=ch[ch.length-1-i])
			{
				return false;
			}
		}
		return true;
	}
}
