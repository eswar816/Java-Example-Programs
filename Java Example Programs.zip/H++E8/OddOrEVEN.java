import java.util.Scanner;
class OddOrEVEN 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		if(checkOddOrEven(num))
		{
			System.out.println(num+" is even");
		}
		else
		{
			System.out.println(num+" is odd");
		}
		
	}
	 public static boolean checkOddOrEven(int num)
	{
		return num/2*2==num?true : false;
	}
}
