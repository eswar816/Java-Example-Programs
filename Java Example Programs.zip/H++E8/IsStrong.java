class IsStrong 
{
	public static void main(String[] args) 
	{
		range();
	}
	public static void range()
	{
		for(int i=1;i<=10000;i++)
		{
			if(isStrong(i))
			{
				System.out.println(i+" is a strong number");
			}
		}
	}
	public static boolean isStrong(int num)
	{
		int temp=num,sum=0;
		while(num>0)
		{
			sum+=factorial(num%10);
			num/=10;
		}
		return sum==temp?true:false;
	}
	public static int factorial(int num)
	{
		int fact=1;
		for(int i=1;i<=num;i++)
		{
			fact=fact*i;
		}
		return fact;
	}
}
