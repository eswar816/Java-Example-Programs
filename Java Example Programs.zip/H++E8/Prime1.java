class Prime1 
{
	public static void main(String[] args) 
	{
		range();
	}
	public static void range()
	{
		for(int i=50;i<=100;i++)
		{
			if(checkPrime(i))
			{
				System.out.println(i+" is a prime number");
			}
		}
	}
	public static boolean checkPrime(int num)
	{
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
}
