import java.util.Scanner;
class CountOfNum 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int num=sc.nextInt();
		System.out.println("Count of "+num+" is "+findCount(num));	
	}
	public static int findCount(int num)
	{
		int count=0;
		if(num==0)
		{
			return 1;
		}
		else
		{
			while(num>0)
			{
				count++;
				num=num/10;
			}
			return count;
		}
	}
}
