import java.util.Scanner;
class SumOfDigits
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		System.out.println("Sum of "+num+" is "+sumDigits(num));
	}
	public static int sumDigits(int num)
	{
		int temp=num,rem,sum=0;
		while(num>0)
		{
			rem=num%10;
			num/=10;
			sum=sum+rem;
		}
		return sum;
	}
}
