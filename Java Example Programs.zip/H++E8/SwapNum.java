import java.util.Scanner;
class SwapNum 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		swap(num1,num2);
	}
	public static void swap(int n1,int n2)
	{
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println(n1+","+n2);
	}
}
