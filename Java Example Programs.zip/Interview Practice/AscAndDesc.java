class AscAndDesc 
{
	public static void main(String[] args) 
	{
		int[] a={2,5,7,8,1,4,3,6};
		desc(a);
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
	public static int[] sort(int[] a)
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a;
	}
	public static int[] desc(int[] a)
	{
		sort(a);
		int s=a.length;
		for(int i=s/2; i<s; i++)
		{
		for(int j=s/2; j<s; j++)
		{
		if(a[i]>a[j])
		{
		int temp = a[i];
		a[i] = a[j];
		a[j] = temp;
		}
		}
		}
		return a;
	}
}
