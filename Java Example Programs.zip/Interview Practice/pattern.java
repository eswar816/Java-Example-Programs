public class pattern
{
    public static void main(String[] args)
    {
	int rows=5;
	int r1=rows;
 
    for (int i= rows-1; i>=0 ; i--)
    {
    for (int j=0; j<=i; j++)
    {
		System.out.print(rows*r1+" ");
		r1--;
    }
	rows--;
	r1=rows;
    System.out.println();
    }
    }
    }