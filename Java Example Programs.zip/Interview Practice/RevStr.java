class RevStr 
{
	public static void main(String[] args) 
	{
		String str="Hello";
		strRev(str);
	}
	public static void strRev(String str)
	{
		String str2="";
		for(int i=str.length()-1;i>=0;i--)
		{
			char temp=str.charAt(i);
			str2+=temp;
		}
		System.out.println("Reversed String is "+str2);
	}
}
