class Palindrome 
{
	public static void main(String[] args) 
	{
		int n=2321;
		if(palin(n))
		{
			System.out.println(n+" is a palindrome");
		}
		else
		{
			System.out.println(n+" is a not palindrome");
		}
		
	}
	public static boolean palin(int n)
	{
		int temp=n,rev=0,rem;
		while(n!=0)
		{
			rem=n%10;
			n/=10;
			rev=rev*10+rem;
		}
		if(rev==temp)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
