class RemoveCharacter 
{
	public static void main(String[] args) 
	{
		String s="REMOVE OCCURRENCES";
		
		System.out.println(remChar(s,'E'));
	}
	public static String remChar(String s,char key)
	{
		String s1="";
		char[] ch = new char[s.length()];
  
		    for (int i = 0; i < s.length(); i++) {
				ch[i] = s.charAt(i);
			}
		for(int i=0;i<s.length();i++)
		{
			if(ch[i]==key)
			{
				ch[i]='0';
			}
		}
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]!='0')
			{
				s1+=ch[i];
			}
		}
		return s1;
	}
}
