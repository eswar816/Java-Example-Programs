class SelectionSort 
{
	public static void main(String[] args) 
	{
		int[] a={3,5,6,8,1,-5,-3};
		selection(a);
		System.out.println("After sorting are");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static int[] selection(int[] a)
	{
		int i,j;
		for(i=0;i<a.length;i++)
		{
			int min=i;
			for(j=i+1;j<a.length;j++)
			{
				if(a[min]>a[j])
				{
					min=j;
				}
			}
			int temp=a[min];
			a[min]=a[i];
			a[i]=temp;
		}
		return a;
	}
}
